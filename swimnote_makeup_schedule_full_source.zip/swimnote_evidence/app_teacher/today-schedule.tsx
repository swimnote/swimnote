/**
 * (teacher)/today-schedule.tsx — 오늘 스케줄 탭 (thin shell)
 * 컴포넌트: components/teacher/today-schedule/
 */
import { LucideIcon } from "@/components/common/LucideIcon";
import { XModeBadge } from "@/components/common/XModeBadge";
import { router, useFocusEffect } from "expo-router";
import { Image, Linking, Platform, Pressable } from "react-native";
import React, { useCallback, useEffect, useRef, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Alert, ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, View,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { LogOut, PenLine, Repeat, Sun, X } from "lucide-react-native";
import Colors from "@/constants/colors";
import { apiRequest, useAuth } from "@/context/AuthContext";
import { useBrand } from "@/context/BrandContext";
import { useMode } from "@/context/ModeContext";

import ScheduleCard from "@/components/teacher/today-schedule/ScheduleCard";
import { ScheduleCardSkeleton } from "@/components/common/SkeletonBox";
import { haptic } from "@/utils/haptic";
import { onDiaryChanged } from "@/utils/diaryEvents";
import MemoSheet from "@/components/teacher/today-schedule/MemoSheet";
import AbsenceModal from "@/components/teacher/today-schedule/AbsenceModal";
import ScheduleMemoModal from "@/components/teacher/today-schedule/ScheduleMemoModal";
import UnreadMessagesModal from "@/components/teacher/today-schedule/UnreadMessagesModal";
import TeacherRegisterModal from "@/components/teacher/today-schedule/TeacherRegisterModal";
import { ScheduleItem, formatDate, todayStr } from "@/components/teacher/today-schedule/types";
import ClassDetailSheet from "@/components/teacher/my-schedule/ClassDetailSheet";
import { StudentItem } from "@/components/teacher/my-schedule/utils";
import { TeacherClassGroup } from "@/components/teacher/types";
const C = Colors.light;
interface TeacherOverview {
  unread_messages: number;
  pending_diaries_today: number;
  pending_diaries_past: number;
  makeup_count: number;
  pending_parent_requests: number;
}
export default function TodayScheduleScreen() {
  const { token, logout, adminUser, pool, switchRole, setLastUsedRole } = useAuth();
  const { themeColor } = useBrand();
  const { mode } = useMode();
  const insets = useSafeAreaInsets();
  const today = todayStr();
  const [items, setItems]           = useState<ScheduleItem[]>([]);
  const [loading, setLoading]       = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [overview, setOverview]     = useState<TeacherOverview | null>(null);
  const [switching, setSwitching]   = useState(false);
  const [showMemo,       setShowMemo]       = useState(false);
  const [showAbsence,    setShowAbsence]    = useState(false);
  const [showSchedMemo,  setShowSchedMemo]  = useState(false);
  const [notePopupVisible, setNotePopupVisible] = useState(false);
  const [showTeacherRegister, setShowTeacherRegister] = useState(false);
  const [diaryBannerDismissed, setDiaryBannerDismissed] = useState(false);
  useEffect(() => {
    AsyncStorage.getItem("dismissedDiaryBannerDate").then(date => {
      if (date === today) setDiaryBannerDismissed(true);
    });
  }, [today]);
  const dismissDiaryBanner = useCallback(async () => {
    await AsyncStorage.setItem("dismissedDiaryBannerDate", today);
    setDiaryBannerDismissed(true);
  }, [today]);
  const [activeItem, setActiveItem] = useState<ScheduleItem | null>(null);
  const [activeChipGroup,    setActiveChipGroup]    = useState<TeacherClassGroup | null>(null);
  const [chipStudents,       setChipStudents]       = useState<StudentItem[]>([]);
  const [loadingChipStudents,setLoadingChipStudents]= useState(false);
  const [itemStudentsMap,    setItemStudentsMap]    = useState<Record<string, StudentItem[]>>({});
  // 전체 반 목록 (반이동 버튼용)
  const [allGroups,          setAllGroups]          = useState<TeacherClassGroup[]>([]);
  const [allGroupsStatus,    setAllGroupsStatus]    = useState<"idle" | "loading" | "loaded" | "error">("idle");
  // 칩 클릭 시 날짜 기준 학생 명단
  const [chipStudentsByDate, setChipStudentsByDate] = useState<StudentItem[] | undefined>(undefined);
  // 학생명단 로드 상태 — loading/loaded/error 명시 분리 ([] 빈 배열과 에러 구분)
  const [chipStudentsStatus, setChipStudentsStatus] = useState<"idle" | "loading" | "loaded" | "error">("idle");
  // 오래된 응답 차단용 sequence ID
  const chipSeqRef = useRef(0);
  const canSwitchToAdmin = !!(adminUser?.roles?.includes("pool_admin"));
  async function handleSwitchToAdmin() {
    if (switching || !canSwitchToAdmin) return;
    setSwitching(true);
    try {
      await switchRole("pool_admin");
      await setLastUsedRole("pool_admin");
      router.replace("/(admin)/dashboard" as any);
    } catch (e) {
      console.error(e);
      Alert.alert("전환 실패", "관리자 모드로 전환할 수 없습니다. 다시 시도해주세요.");
    } finally {
      setSwitching(false);
    }
  }
  // 전체 담당 반 목록 조회 (반이동 버튼 데이터 소스)
  const loadAllGroups = useCallback(async () => {
    if (!token) return;
    setAllGroupsStatus("loading");
    try {
      const res = await apiRequest(token, "/class-groups");
      if (res.ok) {
        const data = await res.json();
        setAllGroups(Array.isArray(data) ? data : (data.groups ?? []));
        setAllGroupsStatus("loaded");
      } else {
        setAllGroupsStatus("error");
      }
    } catch {
      setAllGroupsStatus("error");
    }
  }, [token]);

  const overviewTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const loadOverview = useCallback(async () => {
    if (!token) return;
    try {
      const res = await apiRequest(token, "/teacher/overview");
      if (res.ok) setOverview(await res.json());
    } catch { /* 무시 */ }
  }, [token]);
  const load = useCallback(async () => {
    try {
      const poolId = (adminUser as any)?.swimming_pool_id || "";
      const month  = today.slice(0, 7);
      const [schedRes, ovRes, holRes] = await Promise.all([
        apiRequest(token, `/today-schedule?date=${today}`),
        apiRequest(token, "/teacher/overview"),
        poolId ? apiRequest(token, `/holidays?pool_id=${poolId}&month=${month}`) : Promise.resolve(null),
      ]);
      let isHoliday = false;
      if (holRes && holRes.ok) {
        const holData = await holRes.json();
        const holidays: any[] = holData.holidays || [];
        isHoliday = holidays.some((h: any) => (h.holiday_date ?? "").slice(0, 10) === today);
      }
      if (schedRes.ok) {
        const schedData: ScheduleItem[] = await schedRes.json();
        if (isHoliday) {
          setItems([]);
        } else {
          setItems(schedData);
          const map: Record<string, StudentItem[]> = {};
          for (const it of schedData) {
            if ((it as any).students) map[it.id] = (it as any).students as StudentItem[];
          }
          if (Object.keys(map).length > 0) setItemStudentsMap(map);
        }
      }
      if (ovRes.ok) setOverview(await ovRes.json());
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [token, today, adminUser]);
  useFocusEffect(useCallback(() => {
    load();
    loadAllGroups();
    overviewTimerRef.current = setInterval(loadOverview, 60_000);
    return () => { if (overviewTimerRef.current) clearInterval(overviewTimerRef.current); };
  }, [load, loadAllGroups, loadOverview]));
  // 일지 생성/삭제 이벤트 구독 → items diary_done 즉시 갱신 + overview 카운트 재조회
  useEffect(() => {
    return onDiaryChanged(ev => {
      if (ev.lessonDate !== today) return;
      setItems(prev => prev.map(item =>
        item.id === ev.classGroupId
          ? { ...item, diary_done: ev.type === "created" }
          : item
      ));
      loadOverview();
    });
  }, [today, loadOverview]);
  const pendingAtt  = items.filter(i => i.student_count > 0 && i.att_present < i.student_count).length;
  const diaryPending = items.filter(i => !i.diary_done).length;
  const sortedItems  = [...items].sort((a, b) => a.schedule_time.localeCompare(b.schedule_time));
  const totalTasks  = items.length * 2;
  const doneTasks   = items.filter(i => i.student_count === 0 || i.att_present >= i.student_count).length
                    + items.filter(i => i.diary_done).length;
  const progressPct = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
  const allDone     = totalTasks > 0 && doneTasks === totalTasks;
  function handleOpenDiaryFromMsg(_diaryId: string) {
    router.push("/(teacher)/diary?backTo=today-schedule" as any);
  }
  function updateItem(id: string, updated: Partial<ScheduleItem>) {
    setItems(prev => prev.map(it => it.id === id ? { ...it, ...updated } : it));
  }
  async function handleChipPress(item: ScheduleItem) {
    haptic.light();
    const group: TeacherClassGroup = {
      id: item.id,
      name: item.name,
      schedule_days: item.schedule_days,
      schedule_time: item.schedule_time,
      student_count: item.student_count,
      level: item.level,
    };
    setActiveChipGroup(group);
    setChipStudents([]);
    // 반 전환 즉시 이전 학생명단 초기화
    setChipStudentsByDate(undefined);
    setChipStudentsStatus("loading");
    chipSeqRef.current += 1;
    const seq = chipSeqRef.current;
    try {
      const res = await apiRequest(token, `/class-groups/${item.id}/students?date=${today}`);
      if (chipSeqRef.current !== seq) return; // 오래된 응답 차단
      if (res.ok) {
        const data = await res.json();
        setChipStudentsByDate(Array.isArray(data) ? data : (data.students ?? []));
        setChipStudentsStatus("loaded");
      } else {
        setChipStudentsStatus("error"); // 에러 — 빈 배열로 대체 금지
      }
    } catch {
      if (chipSeqRef.current === seq) setChipStudentsStatus("error");
    }
  }
  // 반이동/미배정 성공 후 날짜 기준 학생명단 재조회
  const reloadChipStudents = useCallback(async () => {
    if (!token || !activeChipGroup) return;
    chipSeqRef.current += 1;
    const seq = chipSeqRef.current;
    setChipStudentsByDate(undefined);
    setChipStudentsStatus("loading");
    try {
      const res = await apiRequest(token, `/class-groups/${activeChipGroup.id}/students?date=${today}`);
      if (chipSeqRef.current !== seq) return;
      if (res.ok) {
        const data = await res.json();
        setChipStudentsByDate(Array.isArray(data) ? data : (data.students ?? []));
        setChipStudentsStatus("loaded");
      } else {
        setChipStudentsStatus("error");
      }
    } catch {
      if (chipSeqRef.current === seq) setChipStudentsStatus("error");
    }
  }, [token, activeChipGroup, today]);
  function navigateFromChip(navigate: () => void) {
    setActiveChipGroup(null);
    setTimeout(navigate, 200);
  }
  const WEEK_DAYS = ["일","월","화","수","목","금","토"];
  const weekDates = React.useMemo(() => {
    const now = new Date();
    const sun = new Date(now);
    sun.setDate(now.getDate() - now.getDay());
    return Array.from({ length: 7 }, (_, i) => { const d = new Date(sun); d.setDate(sun.getDate() + i); return d; });
  }, []);
  const topPad = insets.top + (Platform.OS === "web" ? 67 : 8);
  if (adminUser && adminUser.is_activated === false) {
    return (
      <SafeAreaView style={h.safe} edges={[]}>
        <View style={[h.header, { paddingTop: topPad }]}>
          <View style={{ flex: 1 }}>
            <Text style={[h.poolName, { color: C.text }]}>승인 대기 중</Text>
            <Text style={h.greeting}>{adminUser.name ?? "선생님"}선생님</Text>
          </View>
          <Pressable onPress={logout} style={h.logoutBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <LogOut size={18} color={C.textMuted} />
          </Pressable>
        </View>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 32, gap: 20 }}>
          <View style={{ width: 80, height: 80, borderRadius: 24, backgroundColor: "#FFF8E1", alignItems: "center", justifyContent: "center", marginBottom: 4 }}>
            <Sun size={36} color="#F59E0B" />
          </View>
          <Text style={{ fontSize: 20, fontFamily: "Pretendard-Regular", color: C.text, textAlign: "center" }}>
            수영장 관리자 승인 대기 중
          </Text>
          <Text style={{ fontSize: 14, fontFamily: "Pretendard-Regular", color: C.textSecondary, textAlign: "center", lineHeight: 22 }}>
            관리자가 가입 요청을 확인하고 있어요.{"\n"}승인되면 수영장 정보가 연결되고{"\n"}스케줄을 확인할 수 있어요.
          </Text>
          <View style={{ borderRadius: 16, backgroundColor: C.card, padding: 16, width: "100%", gap: 10,
            shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 }}>
            <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 12 }}>
              <View style={{ width: 28, height: 28, borderRadius: 8, backgroundColor: "#EFF4FF", alignItems: "center", justifyContent: "center", marginTop: 1 }}>
                <Text style={{ fontSize: 13, fontFamily: "Pretendard-Regular", color: C.tint }}>1</Text>
              </View>
              <Text style={{ flex: 1, fontSize: 13, fontFamily: "Pretendard-Regular", color: C.textSecondary, lineHeight: 20 }}>
                수영장 관리자가 가입 요청을 검토해요
              </Text>
            </View>
            <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 12 }}>
              <View style={{ width: 28, height: 28, borderRadius: 8, backgroundColor: "#EFF4FF", alignItems: "center", justifyContent: "center", marginTop: 1 }}>
                <Text style={{ fontSize: 13, fontFamily: "Pretendard-Regular", color: C.tint }}>2</Text>
              </View>
              <Text style={{ flex: 1, fontSize: 13, fontFamily: "Pretendard-Regular", color: C.textSecondary, lineHeight: 20 }}>
                승인 후 담당 수업과 학생이 연결돼요
              </Text>
            </View>
            <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 12 }}>
              <View style={{ width: 28, height: 28, borderRadius: 8, backgroundColor: "#EFF4FF", alignItems: "center", justifyContent: "center", marginTop: 1 }}>
                <Text style={{ fontSize: 13, fontFamily: "Pretendard-Regular", color: C.tint }}>3</Text>
              </View>
              <Text style={{ flex: 1, fontSize: 13, fontFamily: "Pretendard-Regular", color: C.textSecondary, lineHeight: 20 }}>
                출석체크·일지작성·보강관리를 시작할 수 있어요
              </Text>
            </View>
          </View>
          <Pressable
            onPress={() => router.replace("/(teacher)/today-schedule" as any)}
            style={({ pressed }) => ({ height: 50, borderRadius: 14, paddingHorizontal: 32, borderWidth: 1.5, borderColor: C.border, alignItems: "center", justifyContent: "center", opacity: pressed ? 0.7 : 1, marginTop: 4 })}
          >
            <Text style={{ fontSize: 14, fontFamily: "Pretendard-Regular", color: C.textSecondary }}>새로고침</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }
  return (
    <SafeAreaView style={h.safe} edges={[]}>
      <View style={[h.header, { paddingTop: topPad }]}>
        <View style={{ flex: 1, minWidth: 0 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            <Text style={[h.poolName, { color: C.text }]} numberOfLines={1}>
              {pool?.name ?? "수영장"}
            </Text>
            <XModeBadge />
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 2 }}>
            <Text style={h.greeting} numberOfLines={1}>{adminUser?.name ?? "선생님"}선생님</Text>
            {canSwitchToAdmin && (
              <Pressable style={({ pressed }) => [h.switchChip, { borderColor: "#0F172A30", backgroundColor: "#E6FAF8", opacity: pressed || switching ? 0.7 : 1 }]}
                onPress={handleSwitchToAdmin} disabled={switching}>
                {switching
                  ? <ActivityIndicator size="small" color="#0F172A" />
                  : <><Repeat size={10} color="#0F172A" /><Text style={[h.switchChipTxt, { color: "#0F172A" }]}>관리자로 전환</Text></>}
              </Pressable>
            )}
          </View>
        </View>
        <Pressable
          onPress={() => setNotePopupVisible(true)}
          style={[h.logoutBtn, { marginRight: 8 }]}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <View>
            <LucideIcon name="mail" size={18} color={C.textMuted} />
            {((overview?.unread_messages ?? 0) > 0 || (overview?.pending_parent_requests ?? 0) > 0) && (
              <View style={{
                position: "absolute", top: -3, right: -3,
                width: 8, height: 8, borderRadius: 4, backgroundColor: "#D96C6C",
              }} />
            )}
          </View>
        </Pressable>
        <Pressable
          style={[h.logoutBtn, { marginRight: 8 }]}
          onPress={() => Linking.openURL("https://swimnote.kr")}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Image source={require("@/assets/images/swimnote-logo.png")} style={{ width: 18, height: 18 }} resizeMode="contain" />
        </Pressable>
        <Pressable onPress={logout} style={h.logoutBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <LogOut size={18} color={C.textMuted} />
        </Pressable>
      </View>
      <View style={h.topFixed}>
        <View style={[h.todayBanner, { backgroundColor: C.card }]}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
            <Text style={h.todayDate}>{formatDate(today)}</Text>
            {!loading && totalTasks > 0 && (
              <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                {allDone ? <LucideIcon name="trophy" size={11} color="#F59E0B" /> : null}
                <Text style={{ fontSize: 10, fontFamily: "Pretendard-Regular", color: allDone ? "#F59E0B" : C.textMuted }}>
                  {allDone ? "오늘 완료!" : `${progressPct}%`}
                </Text>
              </View>
            )}
          </View>
          {!loading && totalTasks > 0 && (
            <View style={{ height: 3, backgroundColor: C.border, borderRadius: 2, marginBottom: 8, overflow: "hidden" }}>
              <View style={{
                height: 3, borderRadius: 2,
                backgroundColor: allDone ? "#F59E0B" : themeColor,
                width: `${progressPct}%`,
              }} />
            </View>
          )}
          <View style={h.todayStatRow}>
            <Pressable style={h.todayStat} onPress={() => router.push({ pathname:"/(teacher)/my-schedule", params:{openDate:today, backTo:"today-schedule"} } as any)}>
              <Text style={h.todayStatNum}>{loading ? "-" : items.length}</Text>
              <Text style={h.todayStatLabel}>오늘 수업</Text>
            </Pressable>
            <View style={h.todayDivider} />
            <Pressable style={h.todayStat} onPress={() => router.push("/(teacher)/attendance?backTo=today-schedule" as any)}>
              <Text style={[h.todayStatNum, pendingAtt > 0 && { color: C.error }]}>{loading ? "-" : pendingAtt}</Text>
              <Text style={h.todayStatLabel}>출석 미체크</Text>
            </Pressable>
            <View style={h.todayDivider} />
            <Pressable style={h.todayStat} onPress={() => router.push("/(teacher)/diary?backTo=today-schedule" as any)}>
              <Text style={[h.todayStatNum, diaryPending > 0 && { color: C.error }]}>{loading ? "-" : diaryPending}</Text>
              <Text style={h.todayStatLabel}>미작성 일지</Text>
            </Pressable>
            <View style={h.todayDivider} />
            <Pressable style={h.todayStat} onPress={() => router.push("/(teacher)/makeups?backTo=today-schedule" as any)}>
              <Text style={[h.todayStatNum, (overview?.makeup_count ?? 0) > 0 && { color: C.error }]}>
                {loading ? "-" : (overview?.makeup_count ?? 0)}
              </Text>
              <Text style={h.todayStatLabel}>보강 대기</Text>
            </Pressable>
          </View>
        </View>
        <View style={[h.weekCard, { backgroundColor: C.card }]}>
          {weekDates.map((d, i) => {
            const dayLabel = WEEK_DAYS[i];
            const dateNum  = d.getDate();
            const isToday  = d.toDateString() === new Date().toDateString();
            const hasClass = items.some(it => {
              const days = (it.schedule_days ?? "").split(",").map((s: string) => s.trim());
              return days.includes(dayLabel);
            });
            return (
              <View key={i} style={h.weekCell}>
                <Text style={[h.weekDay, isToday && { color: themeColor, fontWeight: "600" }]}>{dayLabel}</Text>
                <View style={[h.weekDateBox, isToday && { backgroundColor: themeColor }]}>
                  <Text style={[h.weekDate, isToday && { color: "#fff" }]}>{dateNum}</Text>
                </View>
                {hasClass
                  ? <View style={[h.weekDot, { backgroundColor: isToday ? themeColor : C.tint }]} />
                  : <View style={h.weekDotEmpty} />
                }
              </View>
            );
          })}
        </View>
        {!diaryBannerDismissed && (overview?.pending_diaries_today ?? 0) > 0 && (
          <Pressable
            style={[h.feedbackBanner, { backgroundColor: "#7C3AED" }]}
            onPress={() => router.push("/(teacher)/diary?backTo=today-schedule" as any)}
          >
            <View style={h.feedbackBannerLeft}>
              <Text style={h.feedbackBannerTitle}>미작성 일지 {overview!.pending_diaries_today}개</Text>
              <Text style={h.feedbackBannerSub}>학부모가 기다리고 있어요 · 탭해서 작성</Text>
            </View>
            <Pressable onPress={(e) => { e.stopPropagation(); dismissDiaryBanner(); }} hitSlop={10} style={h.feedbackBannerClose}>
              <X size={15} color="rgba(255,255,255,0.85)" />
            </Pressable>
          </Pressable>
        )}

        {/* SWIMNOTE X 빠른 진입 (mode === "x" | "x_pending" 일 때만) */}
        {(mode === "x" || mode === "x_pending") && (
          <Pressable
            style={({ pressed }) => ({
              flexDirection: "row", alignItems: "center", gap: 8,
              backgroundColor: mode === "x" ? "#E6FAF8" : "#F8FAFC",
              borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9,
              borderWidth: 1, borderColor: mode === "x" ? "#2EC4B6" : "#E2E8F0",
              opacity: pressed && mode === "x" ? 0.75 : 1,
            })}
            onPress={() => mode === "x" && router.push("/(teacher)/x-growth" as any)}
            disabled={mode !== "x"}
          >
            <LucideIcon name="trending-up" size={14} color={mode === "x" ? "#2EC4B6" : "#94A3B8"} />
            <Text style={{ fontSize: 12, fontFamily: "Pretendard-Regular", color: mode === "x" ? "#0F172A" : "#94A3B8", flex: 1 }}>
              {mode === "x" ? "성장 추적 →" : "X 설정 완료 후 이용 가능"}
            </Text>
            <View style={{ backgroundColor: mode === "x" ? "#fff" : "#E2E8F0", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 1, borderWidth: 1, borderColor: mode === "x" ? "#2EC4B6" : "#CBD5E1" }}>
              <Text style={{ fontSize: 9, fontFamily: "Pretendard-SemiBold", color: mode === "x" ? "#0F172A" : "#94A3B8" }}>
                SWIMNOTE X
              </Text>
            </View>
          </Pressable>
        )}
      </View>
      <View style={[h.classCardWrap, { paddingBottom: insets.bottom + 12 }]}>
        <View style={[h.sectionCard, { flex: 1, backgroundColor: C.card }]}>
          <View style={h.sectionHeaderRow}>
            <View style={[h.sectionIconBox, { backgroundColor: C.tintLight }]}>
              <LucideIcon name="layers" size={13} color={C.iconSchedule} />
            </View>
            <Text style={h.sectionTitle}>오늘 수업</Text>
            <View style={h.sectionHeaderRight}>
              {!loading && sortedItems.length > 0 && (
                <Text style={[h.classCnt, { color: C.tint }]}>{sortedItems.length}개</Text>
              )}
              <Pressable
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                onPress={() => router.push("/(teacher)/my-schedule?backTo=today-schedule" as any)}>
                <LucideIcon name="calendar" size={16} color={C.textMuted} />
              </Pressable>
            </View>
          </View>
          <ScrollView
            style={{ flex: 1 }}
            showsVerticalScrollIndicator={false}
            nestedScrollEnabled
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={themeColor} />}
          >
            {loading ? (
              <View style={{ gap: 10, paddingTop: 4 }}>
                <ScheduleCardSkeleton />
              </View>
            ) : sortedItems.length === 0 ? (
              <View style={h.badgeEmpty}>
                <View style={{ width: 56, height: 56, borderRadius: 18, backgroundColor: "#FFF8E1", alignItems: "center", justifyContent: "center", marginBottom: 2 }}>
                  <Sun size={26} color="#F59E0B" />
                </View>
                <Text style={{ fontSize: 15, fontFamily: "Pretendard-Regular", color: C.text }}>오늘 수업 없음</Text>
                <Text style={{ fontSize: 12, fontFamily: "Pretendard-Regular", color: C.textMuted }}>편하게 쉬어가세요</Text>
              </View>
            ) : sortedItems.map((item, idx) => {
              const students = itemStudentsMap[item.id] ?? [];
              const names    = students.map((s: any) => s.name ?? s.user_name ?? "").filter(Boolean);
              const MAX = 5;
              const shown    = names.slice(0, MAX);
              const extra    = names.length - MAX;
              const nameStr  = shown.join(", ") + (extra > 0 ? ` 외 ${extra}명` : "");
              const isLast   = idx === sortedItems.length - 1;
              const diaryDone = item.diary_done;
              return (
                <Pressable key={item.id}
                  style={({ pressed }) => [h.listRow, !isLast && h.listRowBorder, pressed && { opacity: 0.85 }]}
                  onPress={() => {
                    haptic.light();
                    router.push({ pathname: "/(teacher)/diary", params: { classGroupId: item.id, className: item.name, backTo: "today-schedule" } } as any);
                  }}>
                  <View style={[h.diaryStatusBar, { backgroundColor: diaryDone ? "#2EC4B6" : "#F59E0B" }]} />
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 2 }}>
                      <Text style={[h.listTime, { color: C.tint }]}>{item.schedule_time}</Text>
                      <Text style={h.listName}>{item.name}</Text>
                      <Text style={[h.listCount, { color: C.textMuted }]}>({item.student_count}명)</Text>
                    </View>
                    {nameStr.length > 0 && (
                      <Text style={h.listNames} numberOfLines={1}>{nameStr}</Text>
                    )}
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 }}>
                      <LucideIcon name="book-open" size={11} color={diaryDone ? "#2EC4B6" : "#F59E0B"} />
                      <Text style={[h.diaryStatusTxt, { color: diaryDone ? "#2EC4B6" : "#F59E0B" }]}>
                        {diaryDone ? "일지 완료" : "일지 미작성"}
                      </Text>
                    </View>
                  </View>
                  <Pressable
                    style={h.detailBtn}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 0 }}
                    onPress={(e) => { e.stopPropagation(); haptic.light(); handleChipPress(item); }}>
                    <LucideIcon name="settings-2" size={16} color={C.textMuted} />
                  </Pressable>
                </Pressable>
              );
            })}
          </ScrollView>
        </View>
      </View>
      <MemoSheet
        visible={showMemo} item={activeItem} date={today} token={token} themeColor={themeColor}
        onClose={() => { setShowMemo(false); setActiveItem(null); }}
        onSaved={updated => { if (activeItem) updateItem(activeItem.id, updated); }}
      />
      <AbsenceModal
        visible={showAbsence} item={activeItem} date={today} token={token} themeColor={themeColor}
        onClose={() => { setShowAbsence(false); setActiveItem(null); }}
        onDone={() => { load(); }}
      />
      <ScheduleMemoModal visible={showSchedMemo} token={token} themeColor={themeColor}
        onClose={() => setShowSchedMemo(false)} />
      <UnreadMessagesModal visible={notePopupVisible} token={token} themeColor={themeColor}
        onClose={() => setNotePopupVisible(false)} onOpenDiary={handleOpenDiaryFromMsg}
        onMessagesRead={() => setOverview(prev => prev ? { ...prev, unread_messages: 0 } : prev)} />
      <TeacherRegisterModal visible={showTeacherRegister} token={token} themeColor={themeColor}
        onClose={() => setShowTeacherRegister(false)} onSuccess={() => {}} />
      {activeChipGroup && (
        <ClassDetailSheet
          group={activeChipGroup}
          students={loadingChipStudents ? [] : chipStudents}
          attMap={Object.fromEntries(items.map(it => [it.id, it.att_present]))}
          diarySet={new Set(items.filter(it => it.diary_done).map(it => it.id))}
          date={today}
          studentsByDate={chipStudentsStatus === "loaded" ? chipStudentsByDate : undefined}
          studentsByDateError={chipStudentsStatus === "error"}
          onRetryStudentsByDate={reloadChipStudents}
          studentListMode="historical"
          classGroups={allGroupsStatus === "loaded" ? allGroups : null}
          classGroupsLoadState={
            allGroupsStatus === "idle" || allGroupsStatus === "loading" ? "loading"
            : allGroupsStatus === "error" ? "error"
            : "loaded"
          }
          onRetryClassGroups={loadAllGroups}
          themeColor={themeColor}
          token={token}
          onClose={() => { setActiveChipGroup(null); setChipStudentsByDate(undefined); setChipStudentsStatus("idle"); load(); }}
          onNavigateTo={navigateFromChip}
          onStudentsChanged={reloadChipStudents}
        />
      )}
      <Pressable
        style={[h.fab, { backgroundColor: themeColor, bottom: insets.bottom + 72 }]}
        onPress={() => { haptic.light(); router.push("/(teacher)/diary?backTo=today-schedule" as any); }}
        accessibilityLabel="일지 바로쓰기"
      >
        <PenLine size={18} color="#fff" />
        <Text style={h.fabText}>일지 바로쓰기</Text>
      </Pressable>
    </SafeAreaView>
  );
}
const h = StyleSheet.create({
  safe:           { flex: 1, backgroundColor: C.background },
  topFixed:       { paddingHorizontal: 12, paddingTop: 12, gap: 8 },
  classCardWrap:  { flex: 1, paddingHorizontal: 12, paddingTop: 8 },
  header:         { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingBottom: 14, backgroundColor: C.background, borderBottomWidth: 1, borderBottomColor: C.border },
  poolName:       { fontSize: 18, fontFamily: "Pretendard-Regular", flexShrink: 1 },
  greeting:       { fontSize: 12, fontFamily: "Pretendard-Regular", color: C.textSecondary, marginTop: 2 },
  logoutBtn:      { width: 38, height: 38, borderRadius: 10, backgroundColor: C.backgroundSoft, alignItems: "center", justifyContent: "center" },
  switchChip:     { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, borderWidth: 1, flexShrink: 0 },
  switchChipTxt:  { fontSize: 11, fontFamily: "Pretendard-Regular" },
  scroll:         { padding: 12, gap: 8 },
  todayBanner:    { borderRadius: 14, paddingHorizontal: 12, paddingVertical: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  todayDate:      { fontSize: 10, fontFamily: "Pretendard-Regular", color: "#64748B", marginBottom: 6 },
  todayStatRow:   { flexDirection: "row", alignItems: "center" },
  todayStat:      { flex: 1, alignItems: "center", gap: 1, paddingVertical: 0 },
  todayStatNum:   { fontSize: 15, fontFamily: "Pretendard-Regular", color: "#0F172A" },
  todayStatLabel: { fontSize: 9, fontFamily: "Pretendard-Regular", color: "#64748B" },
  todayDivider:   { width: 1, height: 18, backgroundColor: C.border },
  sectionCard:    { borderRadius: 14, padding: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  sectionHeaderRow:{ flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 4 },
  sectionIconBox: { width: 24, height: 24, borderRadius: 7, alignItems: "center", justifyContent: "center" },
  sectionTitle:   { fontSize: 13, fontFamily: "Pretendard-Regular", color: C.text },
  sectionMore:    { fontSize: 12, fontFamily: "Pretendard-Regular" },
  classCnt:       { fontSize: 11, fontFamily: "Pretendard-Regular" },
  sectionHeaderRight: { marginLeft: "auto", flexDirection: "row", alignItems: "center", gap: 8 },
  badgeEmpty:     { alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 24 },
  emptyTxt:       { fontSize: 12, fontFamily: "Pretendard-Regular", color: C.textMuted },
  listRow:        { flexDirection: "row", alignItems: "center", paddingVertical: 10, paddingHorizontal: 4, gap: 6 },
  listRowBorder:  { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: C.border },
  listTime:       { fontSize: 12, fontFamily: "Pretendard-Regular", minWidth: 42 },
  listName:       { fontSize: 14, fontFamily: "Pretendard-Regular", color: C.text, flex: 1 },
  listCount:      { fontSize: 12, fontFamily: "Pretendard-Regular" },
  listNames:      { fontSize: 11, fontFamily: "Pretendard-Regular", color: C.text, marginLeft: 50 },
  diaryStatusBar: { width: 3, alignSelf: "stretch", borderRadius: 2, marginRight: 2 },
  diaryStatusTxt: { fontSize: 11, fontFamily: "Pretendard-Regular" },
  detailBtn:      { padding: 8, marginLeft: 4 },
  feedbackBanner:      { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 14, paddingVertical: 13, paddingHorizontal: 16 },
  feedbackBannerLeft:  { flex: 1, gap: 2 },
  feedbackBannerTitle: { fontSize: 14, fontFamily: "Pretendard-Regular", color: "#fff" },
  feedbackBannerSub:   { fontSize: 11, fontFamily: "Pretendard-Regular", color: "rgba(255,255,255,0.75)" },
  feedbackBannerClose: { padding: 6, marginLeft: 4 },
  weekCard:     { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderRadius: 14, paddingVertical: 12, paddingHorizontal: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  weekCell:     { flex: 1, alignItems: "center", gap: 5 },
  weekDay:      { fontSize: 11, fontFamily: "Pretendard-Regular", color: C.textMuted },
  weekDateBox:  { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  weekDate:     { fontSize: 14, fontFamily: "Pretendard-Regular", color: C.text },
  weekDot:      { width: 5, height: 5, borderRadius: 3 },
  weekDotEmpty: { width: 5, height: 5 },
  miniDateToday:    { fontSize: 14, fontFamily: "Pretendard-Regular", color: "#fff" },
  miniDot:          { width: 4, height: 4, borderRadius: 2, backgroundColor: "#2DD4BF", marginTop: -2 },
  fab:              { position: "absolute", right: 20, flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 18, paddingVertical: 13, borderRadius: 28, shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.18, shadowRadius: 10, elevation: 6 },
  fabText:          { color: "#fff", fontSize: 14, fontFamily: "Pretendard-SemiBold", lineHeight: 20 },
});
