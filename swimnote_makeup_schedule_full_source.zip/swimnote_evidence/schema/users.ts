import { pgTable, text, timestamp, pgEnum, boolean, jsonb } from "drizzle-orm/pg-core";

import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const userRoleEnum = pgEnum("user_role", ["super_admin", "pool_admin", "parent", "teacher"]);

export const usersTable = pgTable("users", {
  id: text("id").primaryKey().default("gen_random_uuid()"),
  email: text("email").notNull().unique(),
  password_hash: text("password_hash").notNull(),
  name: text("name").notNull(),
  phone: text("phone"),
  role: userRoleEnum("role").notNull().default("parent"),
  swimming_pool_id: text("swimming_pool_id"),
  is_activated: boolean("is_activated").notNull().default(true),
  is_admin_self_teacher: boolean("is_admin_self_teacher").notNull().default(false),
  phone_verified: boolean("phone_verified").notNull().default(false),
  created_by: text("created_by"),
  permissions: jsonb("permissions"),
  roles: text("roles").array().notNull().default([]),
  totp_secret: text("totp_secret"),
  totp_enabled: boolean("totp_enabled").notNull().default(false),
  withdrawal_requested_at: timestamp("withdrawal_requested_at"),
  created_at: timestamp("created_at").notNull().defaultNow(),
  updated_at: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({
  id: true,
  created_at: true,
  updated_at: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
